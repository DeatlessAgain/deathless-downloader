/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  DownloadItem,
  QualityOption,
  BatchItem,
  ExtractedMediaInfo,
} from './types';
import { inspectMediaUrl, generateStandardQualities } from './services/urlParser';
import {
  loadSettings,
  saveSettings,
  getDownloadHistory,
  saveDownloadHistory,
  createDownloadItem,
  AppSettings,
  triggerBrowserFileDownload,
} from './services/downloadEngine';
import { createEncryptedMediaRecord } from './services/cryptoVault';

import { Header } from './components/Header';
import { UrlInputBar } from './components/UrlInputBar';
import { DownloadModal } from './components/DownloadModal';
import { ActiveDownloads } from './components/ActiveDownloads';
import { SocialFeedBrowser } from './components/SocialFeedBrowser';
import { BatchPlaylistDownloader } from './components/BatchPlaylistDownloader';
import { OfflineVault } from './components/OfflineVault';
import { DownloadHistory } from './components/DownloadHistory';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  // Dark mode defaults to OFF (Light mode) as requested by user
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('deathless_dark_mode');
    return saved === 'true'; // defaults to false if not saved
  });

  const [currentTab, setCurrentTab] = useState<'downloader' | 'social' | 'batch' | 'vault' | 'history'>('downloader');
  const [settings, setSettings] = useState<AppSettings>(loadSettings);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Active Downloads & History
  const [activeItems, setActiveItems] = useState<DownloadItem[]>([]);
  const [history, setHistory] = useState<DownloadItem[]>(getDownloadHistory);

  // Analyzing & Modal state
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [pendingMediaInfo, setPendingMediaInfo] = useState<ExtractedMediaInfo | null>(null);
  const [isQualityModalOpen, setIsQualityModalOpen] = useState(false);

  // Active item to play in vault
  const [vaultFileToPlay, setVaultFileToPlay] = useState<string | null>(null);

  // Aggregate Speed
  const [totalSpeedMbps, setTotalSpeedMbps] = useState(0);

  // Save dark mode preference
  useEffect(() => {
    localStorage.setItem('deathless_dark_mode', darkMode.toString());
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Main Download Engine Tick Loop (Handles multi-chunk parallel transfers & deathless resumes)
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveItems((prev) => {
        let currentAggregateSpeedBytes = 0;
        let hasChanges = false;

        const updated = prev.map((item) => {
          if (item.status !== 'downloading' && item.status !== 'resuming') {
            return item;
          }

          hasChanges = true;
          // Target transfer speed between 25 MB/s and 75 MB/s
          const baseSpeedBytes = (35 + Math.random() * 40) * 1024 * 1024;
          const tickIntervalSec = 0.2;
          const bytesToAdvance = Math.floor(baseSpeedBytes * tickIntervalSec);

          const newDownloaded = Math.min(item.totalBytes, item.downloadedBytes + bytesToAdvance);
          currentAggregateSpeedBytes += baseSpeedBytes;

          // Advance individual chunks
          const chunkShare = Math.floor(bytesToAdvance / (item.chunks.length || 1));
          const updatedChunks = item.chunks.map((chunk) => {
            const newChunkBytes = Math.min(chunk.totalBytes, chunk.downloadedBytes + chunkShare);
            return {
              ...chunk,
              downloadedBytes: newChunkBytes,
              status: newChunkBytes >= chunk.totalBytes ? ('completed' as const) : ('downloading' as const),
              speedMbps: baseSpeedBytes / (1024 * 1024 * item.chunks.length),
            };
          });

          // Check if completed
          if (newDownloaded >= item.totalBytes) {
            const completedItem: DownloadItem = {
              ...item,
              downloadedBytes: item.totalBytes,
              status: 'completed',
              speedBytesPerSec: 0,
              etaSeconds: 0,
              completedAt: Date.now(),
              chunks: updatedChunks.map((c) => ({ ...c, status: 'completed' as const })),
            };

            // Trigger celebration
            try {
              confetti({ particleCount: 50, spread: 60, origin: { y: 0.8 } });
            } catch {
              // Ignore if blocked
            }

            // Save to encrypted offline vault if requested
            if (completedItem.isEncrypted) {
              createEncryptedMediaRecord(
                completedItem.title,
                completedItem.category,
                completedItem.format,
                completedItem.quality.label,
                completedItem.totalBytes,
                completedItem.thumbnail
              ).catch((err) => console.error('Failed to vault:', err));
            }

            // Append to history
            setHistory((prevHist) => {
              const newHist = [completedItem, ...prevHist];
              saveDownloadHistory(newHist);
              return newHist;
            });

            return completedItem;
          }

          const remainingBytes = item.totalBytes - newDownloaded;
          const eta = Math.ceil(remainingBytes / (baseSpeedBytes || 1));

          return {
            ...item,
            downloadedBytes: newDownloaded,
            speedBytesPerSec: baseSpeedBytes,
            etaSeconds: eta,
            chunks: updatedChunks,
          };
        });

        setTotalSpeedMbps(currentAggregateSpeedBytes / (1024 * 1024));
        return hasChanges ? updated : prev;
      });
    }, 200);

    return () => clearInterval(interval);
  }, []);

  // Handle URL analyze (from Manual input or Social media feed)
  const handleAnalyzeUrl = (rawUrl: string, autoStartImmediately = false) => {
    if (!rawUrl.trim()) return;
    setIsAnalyzing(true);

    setTimeout(() => {
      const extracted = inspectMediaUrl(rawUrl);
      setIsAnalyzing(false);

      if (autoStartImmediately || settings.autoStartOnPaste) {
        // Auto start on paste: use preferred quality from settings or top match
        const preferredTag = settings.defaultVideoQuality || '1080p';
        const defQuality =
          extracted.availableQualities.find((q) => q.qualityTag === preferredTag) ||
          extracted.availableQualities.find((q) => q.qualityTag === '1080p') ||
          extracted.availableQualities[0];
        startDownloadWithQuality(extracted, defQuality, settings.saveToEncryptedVault);
      } else {
        // Show quality modal
        setPendingMediaInfo(extracted);
        setIsQualityModalOpen(true);
      }
    }, 400);
  };

  const startDownloadWithQuality = (
    info: ExtractedMediaInfo,
    quality: QualityOption,
    encryptInVault: boolean
  ) => {
    const newItem = createDownloadItem(info, quality, true, encryptInVault);
    setActiveItems((prev) => [newItem, ...prev]);
    setCurrentTab('downloader');
  };

  // Pause / Resume individual transfer
  const handleTogglePause = (id: string) => {
    setActiveItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const isPaused = item.status === 'paused';
        return {
          ...item,
          status: isPaused ? ('downloading' as const) : ('paused' as const),
          speedBytesPerSec: isPaused ? item.speedBytesPerSec : 0,
        };
      })
    );
  };

  // Simulate network drop & automatic deathless resume
  const handleSimulateDrop = (id: string) => {
    setActiveItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        return {
          ...item,
          status: 'resuming',
          speedBytesPerSec: 0,
          autoResumeCount: item.autoResumeCount + 1,
          chunks: item.chunks.map((c) => ({ ...c, status: 'retrying' as const })),
        };
      })
    );

    // Auto recover after 2 seconds
    setTimeout(() => {
      setActiveItems((prev) =>
        prev.map((item) => {
          if (item.id !== id) return item;
          return {
            ...item,
            status: 'downloading',
            chunks: item.chunks.map((c) => ({ ...c, status: 'downloading' as const })),
          };
        })
      );
    }, 2000);
  };

  // Cancel / remove task
  const handleCancel = (id: string) => {
    setActiveItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Bulk actions
  const handlePauseAll = () => {
    setActiveItems((prev) =>
      prev.map((i) => (i.status === 'downloading' ? { ...i, status: 'paused' as const, speedBytesPerSec: 0 } : i))
    );
  };

  const handleResumeAll = () => {
    setActiveItems((prev) =>
      prev.map((i) => (i.status === 'paused' ? { ...i, status: 'downloading' as const } : i))
    );
  };

  const handleClearCompleted = () => {
    setActiveItems((prev) => prev.filter((i) => i.status !== 'completed'));
  };

  // Batch queue handler
  const handleQueueBatch = (batchItems: BatchItem[]) => {
    const newDownloads: DownloadItem[] = batchItems.map((b) => {
      const mediaInfo = inspectMediaUrl(b.url);
      mediaInfo.title = b.title;
      return createDownloadItem(mediaInfo, b.quality, true, settings.saveToEncryptedVault);
    });

    setActiveItems((prev) => [...newDownloads, ...prev]);
    setCurrentTab('downloader');
  };

  // Open in Vault
  const handleOpenInVault = (downloadId: string) => {
    setVaultFileToPlay(downloadId);
    setCurrentTab('vault');
  };

  // Clear history
  const handleClearHistory = () => {
    setHistory([]);
    saveDownloadHistory([]);
  };

  // Remove history item
  const handleRemoveHistoryItem = (id: string) => {
    const updated = history.filter((h) => h.id !== id);
    setHistory(updated);
    saveDownloadHistory(updated);
  };

  // Re-download from history
  const handleRedownload = (item: DownloadItem) => {
    const mediaInfo = inspectMediaUrl(item.originalUrl);
    mediaInfo.title = item.title;
    startDownloadWithQuality(mediaInfo, item.quality, item.isEncrypted);
  };

  // Save Settings
  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const activeDownloadingCount = activeItems.filter(
    (i) => i.status === 'downloading' || i.status === 'resuming'
  ).length;

  return (
    <div
      className={`min-h-screen font-sans transition-colors duration-200 ${
        darkMode ? 'bg-zinc-950 text-zinc-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* App Header */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        activeCount={activeDownloadingCount}
        totalSpeedMbps={totalSpeedMbps}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* URL Input Bar is always accessible on Downloader tab or can be quick-pasted anytime */}
        {currentTab === 'downloader' && (
          <UrlInputBar
            onAnalyzeUrl={handleAnalyzeUrl}
            autoStartOnPaste={settings.autoStartOnPaste}
            setAutoStartOnPaste={(val) => {
              const updated = { ...settings, autoStartOnPaste: val };
              setSettings(updated);
              saveSettings(updated);
            }}
            darkMode={darkMode}
            isAnalyzing={isAnalyzing}
          />
        )}

        {/* Dynamic Tab Views */}
        {currentTab === 'downloader' && (
          <ActiveDownloads
            items={activeItems}
            onTogglePause={handleTogglePause}
            onCancel={handleCancel}
            onSimulateDrop={handleSimulateDrop}
            onRetry={handleTogglePause}
            onPauseAll={handlePauseAll}
            onResumeAll={handleResumeAll}
            onClearCompleted={handleClearCompleted}
            onOpenInVault={handleOpenInVault}
            darkMode={darkMode}
          />
        )}

        {currentTab === 'social' && (
          <SocialFeedBrowser
            onSelectVideoForDownload={(url) => handleAnalyzeUrl(url, false)}
            darkMode={darkMode}
          />
        )}

        {currentTab === 'batch' && (
          <BatchPlaylistDownloader onQueueBatch={handleQueueBatch} darkMode={darkMode} />
        )}

        {currentTab === 'vault' && (
          <OfflineVault initialFileToPlay={vaultFileToPlay} darkMode={darkMode} />
        )}

        {currentTab === 'history' && (
          <DownloadHistory
            history={history}
            onClearHistory={handleClearHistory}
            onRemoveItem={handleRemoveHistoryItem}
            onRedownload={handleRedownload}
            onOpenInVault={handleOpenInVault}
            darkMode={darkMode}
          />
        )}
      </main>

      {/* Quality & Format Pop-Up Modal */}
      {isQualityModalOpen && pendingMediaInfo && (
        <DownloadModal
          info={pendingMediaInfo}
          onClose={() => {
            setIsQualityModalOpen(false);
            setPendingMediaInfo(null);
          }}
          onConfirmDownload={(quality, encryptInVault) => {
            startDownloadWithQuality(pendingMediaInfo, quality, encryptInVault);
          }}
          darkMode={darkMode}
        />
      )}

      {/* Settings Modal */}
      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          onSave={handleSaveSettings}
          onClose={() => setIsSettingsOpen(false)}
          darkMode={darkMode}
          onToggleDarkMode={(val) => setDarkMode(val)}
        />
      )}
    </div>
  );
}
