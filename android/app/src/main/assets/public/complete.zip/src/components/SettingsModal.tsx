import React, { useState } from 'react';
import {
  X,
  Settings as SettingsIcon,
  ShieldCheck,
  Zap,
  Sliders,
  Check,
  Moon,
  Sun,
  FolderDown,
  Film,
  Music,
  Gauge,
  Bell,
  Volume2,
} from 'lucide-react';
import { AppSettings } from '../services/downloadEngine';
import {
  playCompletionChime,
  isNotificationSupported,
  getNotificationPermission,
  requestNotificationPermission,
  sendDesktopNotification,
} from '../services/notificationService';

interface SettingsModalProps {
  settings: AppSettings;
  onSave: (newSettings: AppSettings) => void;
  onClose: () => void;
  darkMode: boolean;
  onToggleDarkMode?: (value: boolean) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onSave,
  onClose,
  darkMode,
  onToggleDarkMode,
}) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
  const [localDarkMode, setLocalDarkMode] = useState<boolean>(darkMode);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission | 'unsupported'>(
    getNotificationPermission()
  );
  const [testedSound, setTestedSound] = useState(false);

  const handleRequestPermission = async () => {
    const granted = await requestNotificationPermission();
    setNotifPermission(getNotificationPermission());
    if (granted) {
      sendDesktopNotification(
        'Deathless Downloader',
        'Desktop notifications are enabled! You will be alerted when downloads finish.'
      );
    }
  };

  const handleTestSound = () => {
    playCompletionChime();
    setTestedSound(true);
    setTimeout(() => setTestedSound(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedSettings = { ...localSettings, darkMode: localDarkMode };
    onSave(updatedSettings);
    if (onToggleDarkMode && localDarkMode !== darkMode) {
      onToggleDarkMode(localDarkMode);
    }
    onClose();
  };

  const handleDarkModeSwitch = (enabled: boolean) => {
    setLocalDarkMode(enabled);
    if (onToggleDarkMode) {
      onToggleDarkMode(enabled);
    }
  };

  return (
    <div
      id="settings-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm animate-fadeIn overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="settings-modal-dialog"
        className={`w-full max-w-lg rounded-2xl border shadow-2xl overflow-hidden my-auto transition-all ${
          darkMode ? 'bg-zinc-900 border-zinc-700 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
              <SettingsIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base">Application & Engine Settings</h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Configure theme, auto-start, storage directories & format defaults
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs sm:text-sm max-h-[75vh] overflow-y-auto">
          {/* Setting 1: Dark Mode Toggle (Explicitly requested by user: turned off by default) */}
          <div className="p-3.5 rounded-xl border border-cyan-500/30 bg-cyan-500/5 flex items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 mt-0.5">
                {localDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
              </div>
              <div>
                <div className="font-bold text-slate-900 dark:text-zinc-100 flex items-center gap-2">
                  <span>Dark Mode Theme</span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-200 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400">
                    {localDarkMode ? 'Dark Active' : 'Off by Default'}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                  Toggle between high-contrast daylight theme and sleek midnight dark aesthetic.
                </p>
              </div>
            </div>

            {/* Switch button */}
            <button
              type="button"
              id="settings-dark-mode-toggle"
              onClick={() => handleDarkModeSwitch(!localDarkMode)}
              className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                localDarkMode ? 'bg-cyan-600' : 'bg-slate-300 dark:bg-zinc-700'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                  localDarkMode ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Setting 2: Auto-Start on Paste Option */}
          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-100 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-950/40">
            <div>
              <div className="font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-2">
                <Zap className="w-3.5 h-3.5 text-cyan-500" />
                <span>Automatically Start Downloading When Link is Pasted</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                Instant queue execution using your preferred defaults without waiting for the format modal
              </p>
            </div>
            <input
              type="checkbox"
              id="settings-auto-start-input"
              checked={localSettings.autoStartOnPaste}
              onChange={(e) =>
                setLocalSettings({ ...localSettings, autoStartOnPaste: e.target.checked })
              }
              className="w-4 h-4 rounded text-cyan-600 accent-cyan-600 cursor-pointer ml-3 flex-shrink-0"
            />
          </div>

          {/* Setting 3: Default Download Location / Folder */}
          <div className="p-3.5 rounded-xl border border-slate-100 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-950/40 space-y-1.5">
            <label className="font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5">
              <FolderDown className="w-3.5 h-3.5 text-cyan-500" />
              <span>Default Download Directory Path</span>
            </label>
            <p className="text-xs text-slate-500 dark:text-zinc-400">
              Files are tracked and saved to this path in your Download History
            </p>
            <input
              type="text"
              id="settings-download-folder-input"
              value={localSettings.defaultDownloadFolder || '~/Downloads/Deathless'}
              onChange={(e) =>
                setLocalSettings({ ...localSettings, defaultDownloadFolder: e.target.value })
              }
              placeholder="e.g. ~/Downloads/Deathless"
              className={`w-full px-3 py-2 rounded-xl text-xs font-mono border outline-none ${
                darkMode
                  ? 'bg-zinc-950 border-zinc-700 text-zinc-100 focus:border-cyan-500'
                  : 'bg-white border-slate-300 text-slate-900 focus:border-cyan-500'
              }`}
            />
          </div>

          {/* Setting 4: Default Video Format & Quality */}
          <div className="p-3.5 rounded-xl border border-slate-100 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-950/40 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5">
                <Film className="w-3.5 h-3.5 text-cyan-500" />
                <span>Preferred Video Format & Quality</span>
              </span>
              <span className="font-mono text-xs text-cyan-600 dark:text-cyan-400 font-bold uppercase">
                .{localSettings.defaultVideoFormat} • {localSettings.defaultVideoQuality}
              </span>
            </div>

            {/* Video Format Buttons */}
            <div className="grid grid-cols-3 gap-2">
              {(['mp4', 'mkv', 'webm'] as const).map((fmt) => (
                <button
                  key={fmt}
                  type="button"
                  onClick={() => setLocalSettings({ ...localSettings, defaultVideoFormat: fmt })}
                  className={`py-1.5 rounded-lg border text-xs font-bold uppercase transition-all ${
                    localSettings.defaultVideoFormat === fmt
                      ? 'bg-cyan-600 text-white border-cyan-600'
                      : darkMode
                        ? 'bg-zinc-900 border-zinc-700 text-zinc-300'
                        : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  .{fmt}
                </button>
              ))}
            </div>

            {/* Video Quality Buttons */}
            <div className="grid grid-cols-4 gap-1.5">
              {(['4K', '1080p', '720p', '360p'] as const).map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setLocalSettings({ ...localSettings, defaultVideoQuality: q })}
                  className={`py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                    localSettings.defaultVideoQuality === q
                      ? 'bg-cyan-600 text-white border-cyan-600'
                      : darkMode
                        ? 'bg-zinc-900 border-zinc-700 text-zinc-300'
                        : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Setting 5: Default Audio Bitrate & Format */}
          <div className="p-3.5 rounded-xl border border-slate-100 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-950/40 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5">
                <Music className="w-3.5 h-3.5 text-cyan-500" />
                <span>Preferred Audio Bitrate & Encoding</span>
              </span>
              <span className="font-mono text-xs text-cyan-600 dark:text-cyan-400 font-bold uppercase">
                .{localSettings.defaultAudioFormat || 'mp3'} • {localSettings.defaultAudioQuality}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {['320k', '256k', '192k', '128k'].map((bitrate) => (
                <button
                  key={bitrate}
                  type="button"
                  onClick={() => setLocalSettings({ ...localSettings, defaultAudioQuality: bitrate as any })}
                  className={`py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                    localSettings.defaultAudioQuality === bitrate
                      ? 'bg-cyan-600 text-white border-cyan-600'
                      : darkMode
                        ? 'bg-zinc-900 border-zinc-700 text-zinc-300'
                        : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {bitrate === '320k' ? '320k (Max)' : bitrate}
                </button>
              ))}
            </div>
          </div>

          {/* Setting 6: Encrypted Vault Checkbox */}
          <div className="flex items-center justify-between p-3.5 rounded-xl border border-slate-100 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-950/40">
            <div>
              <div className="font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Store Encrypted In-App Offline Copies</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                Store AES-GCM encrypted media chunks for instant playback in the offline player
              </p>
            </div>
            <input
              type="checkbox"
              id="settings-save-vault-input"
              checked={localSettings.saveToEncryptedVault}
              onChange={(e) =>
                setLocalSettings({ ...localSettings, saveToEncryptedVault: e.target.checked })
              }
              className="w-4 h-4 rounded text-cyan-600 accent-cyan-600 cursor-pointer ml-3 flex-shrink-0"
            />
          </div>

          {/* Setting 7: Parallel Chunk Streams */}
          <div className="p-3.5 rounded-xl border border-slate-100 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-950/40 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 dark:text-zinc-200">
                Parallel Multi-Thread Range Streams
              </span>
              <span className="font-mono font-bold text-cyan-600 dark:text-cyan-400">
                {localSettings.chunkCount} HTTP/3 Channels
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[4, 8, 16].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setLocalSettings({ ...localSettings, chunkCount: num })}
                  className={`py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                    localSettings.chunkCount === num
                      ? 'bg-cyan-600 text-white border-cyan-600'
                      : darkMode
                        ? 'bg-zinc-900 border-zinc-700 text-zinc-300'
                        : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {num} Channels
                </button>
              ))}
            </div>
          </div>

          {/* Setting 8: Download Speed Limit (Bandwidth Cap) */}
          <div className="p-3.5 rounded-xl border border-slate-100 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-950/40 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-cyan-500" />
                <span>Download Speed Limit</span>
              </span>
              <span className="font-mono font-bold text-xs text-cyan-600 dark:text-cyan-400">
                {localSettings.downloadSpeedLimitMbps === 0
                  ? 'Unlimited (Max Network)'
                  : `${localSettings.downloadSpeedLimitMbps} MB/s Cap`}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-zinc-400">
              Throttle aggregate bandwidth to prevent network congestion or let streams consume full gigabit line.
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              {[
                { val: 0, label: 'Unlimited' },
                { val: 50, label: '50 MB/s' },
                { val: 25, label: '25 MB/s' },
                { val: 10, label: '10 MB/s' },
                { val: 5, label: '5 MB/s' },
                { val: 2, label: '2 MB/s' },
              ].map((opt) => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() =>
                    setLocalSettings({ ...localSettings, downloadSpeedLimitMbps: opt.val })
                  }
                  className={`py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                    (localSettings.downloadSpeedLimitMbps ?? 0) === opt.val
                      ? 'bg-cyan-600 text-white border-cyan-600'
                      : darkMode
                        ? 'bg-zinc-900 border-zinc-700 text-zinc-300'
                        : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Setting 9: Auto Notify Downloads */}
          <div className="p-3.5 rounded-xl border border-slate-100 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-950/40 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-1.5">
                <Bell className="w-4 h-4 text-cyan-500" />
                <span>Auto Notify Downloads</span>
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-600 dark:text-cyan-400">
                Audio & Desktop Alerts
              </span>
            </div>

            {/* Desktop Notification Toggle */}
            <div className="flex items-center justify-between pt-1">
              <div>
                <div className="font-medium text-xs text-slate-800 dark:text-zinc-200">
                  Desktop System Notifications
                </div>
                <div className="text-[11px] text-slate-500 dark:text-zinc-400">
                  Show OS alert popup with file name and size when download finishes
                </div>
              </div>
              <div className="flex items-center gap-2">
                {notifPermission !== 'granted' && isNotificationSupported() && (
                  <button
                    type="button"
                    onClick={handleRequestPermission}
                    className="px-2 py-1 rounded text-[10px] font-semibold bg-cyan-600/10 text-cyan-600 dark:text-cyan-400 hover:bg-cyan-600/20 transition-colors"
                  >
                    Enable Browser Perms
                  </button>
                )}
                <input
                  type="checkbox"
                  id="settings-desktop-notif-input"
                  checked={localSettings.desktopNotifications ?? true}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, desktopNotifications: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-cyan-600 accent-cyan-600 cursor-pointer"
                />
              </div>
            </div>

            {/* Sound Notification Toggle */}
            <div className="flex items-center justify-between border-t border-slate-100 dark:border-zinc-800/80 pt-2">
              <div>
                <div className="font-medium text-xs text-slate-800 dark:text-zinc-200 flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Completion Audio Chime</span>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-zinc-400">
                  Play melodic two-tone chime when a download completes successfully
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleTestSound}
                  className={`px-2 py-1 rounded text-[10px] font-semibold border transition-colors ${
                    testedSound
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500'
                      : darkMode
                        ? 'bg-zinc-800 border-zinc-700 text-zinc-300'
                        : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {testedSound ? 'Chimed!' : 'Test Sound'}
                </button>
                <input
                  type="checkbox"
                  id="settings-sound-notif-input"
                  checked={localSettings.soundNotifications ?? true}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, soundNotifications: e.target.checked })
                  }
                  className="w-4 h-4 rounded text-cyan-600 accent-cyan-600 cursor-pointer"
                />
              </div>
            </div>

            {/* In-App Toast Toggle */}
            <div className="flex items-center justify-between border-t border-slate-100 dark:border-zinc-800/80 pt-2">
              <div>
                <div className="font-medium text-xs text-slate-800 dark:text-zinc-200">
                  In-App Toast Banner Alerts
                </div>
                <div className="text-[11px] text-slate-500 dark:text-zinc-400">
                  Show floating status alert in top-right corner with direct actions
                </div>
              </div>
              <input
                type="checkbox"
                id="settings-toast-notif-input"
                checked={localSettings.inAppToastNotifications ?? true}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, inAppToastNotifications: e.target.checked })
                }
                className="w-4 h-4 rounded text-cyan-600 accent-cyan-600 cursor-pointer"
              />
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className={`px-4 py-2 rounded-xl text-xs font-semibold border ${
                darkMode ? 'border-zinc-700 hover:bg-zinc-800 text-zinc-300' : 'border-slate-200 hover:bg-slate-100 text-slate-700'
              }`}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-600/20"
            >
              Save Preferences
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
