import { DownloadItem, ChunkProgress, QualityOption, ExtractedMediaInfo } from '../types';
import { createEncryptedMediaRecord } from './cryptoVault';

const HISTORY_KEY = 'deathless_downloader_history_v1';
const SETTINGS_KEY = 'deathless_downloader_settings_v1';

export interface AppSettings {
  darkMode: boolean;
  autoStartOnPaste: boolean;
  maxConcurrentDownloads: number;
  defaultVideoFormat: 'mp4' | 'mkv' | 'webm';
  defaultVideoQuality: '4K' | '2K' | '1080p' | '720p' | '480p' | '360p';
  defaultAudioQuality: '320k' | '256k' | '192k' | '128k';
  defaultAudioFormat: 'mp3' | 'm4a' | 'flac' | 'wav';
  defaultDownloadFolder: string;
  saveToEncryptedVault: boolean;
  chunkCount: number;
  downloadSpeedLimitMbps: number; // 0 = unlimited
  soundNotifications: boolean;
  desktopNotifications: boolean;
  inAppToastNotifications: boolean;
}

export const defaultSettings: AppSettings = {
  darkMode: false, // Turned OFF by default as requested
  autoStartOnPaste: false,
  maxConcurrentDownloads: 3,
  defaultVideoFormat: 'mp4',
  defaultVideoQuality: '1080p',
  defaultAudioQuality: '320k',
  defaultAudioFormat: 'mp3',
  defaultDownloadFolder: '~/Downloads/Deathless',
  saveToEncryptedVault: true,
  chunkCount: 8,
  downloadSpeedLimitMbps: 0,
  soundNotifications: true,
  desktopNotifications: true,
  inAppToastNotifications: true,
};

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    return raw ? { ...defaultSettings, ...JSON.parse(raw) } : defaultSettings;
  } catch {
    return defaultSettings;
  }
}

export function saveSettings(settings: AppSettings): void {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export function getDownloadHistory(): DownloadItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return getDefaultInitialHistory();
    return JSON.parse(raw);
  } catch {
    return getDefaultInitialHistory();
  }
}

export function saveDownloadHistory(history: DownloadItem[]): void {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  } catch (err) {
    console.error('Failed to save history to storage:', err);
  }
}

export function createDownloadItem(
  info: ExtractedMediaInfo,
  quality: QualityOption,
  autoStart = true,
  encryptInVault = true
): DownloadItem {
  const totalBytes = quality.approxSizeMb * 1024 * 1024;
  const chunkCount = 8;
  const chunkSize = Math.floor(totalBytes / chunkCount);

  const chunks: ChunkProgress[] = Array.from({ length: chunkCount }, (_, idx) => {
    const startByte = idx * chunkSize;
    const endByte = idx === chunkCount - 1 ? totalBytes - 1 : (idx + 1) * chunkSize - 1;
    return {
      id: idx,
      startByte,
      endByte,
      downloadedBytes: 0,
      totalBytes: endByte - startByte + 1,
      status: 'pending',
      speedMbps: 0,
    };
  });

  const settings = loadSettings();
  const safeName = info.title
    .replace(/[^a-zA-Z0-9_\-\s]/g, '')
    .trim()
    .replace(/\s+/g, '_')
    .substring(0, 50);
  const ext = (quality.format || 'mp4').toLowerCase();
  const fileName = `${safeName || 'download'}_${quality.qualityTag}.${ext}`;
  const folder = settings.defaultDownloadFolder || '~/Downloads/Deathless';
  const downloadPath = `${folder}/${fileName}`;

  const item: DownloadItem = {
    id: 'dl_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    title: info.title,
    fileName,
    downloadPath,
    originalUrl: info.url,
    platform: info.platform,
    category: quality.isAudioOnly ? 'audio' : 'video',
    format: quality.format,
    quality,
    totalBytes,
    downloadedBytes: 0,
    status: autoStart ? 'downloading' : 'queued',
    speedBytesPerSec: 0,
    etaSeconds: 0,
    chunks,
    thumbnail: info.thumbnail,
    duration: info.duration,
    createdAt: Date.now(),
    cdnInfo: info.cdnInfo,
    isEncrypted: encryptInVault,
    vaultStored: false,
    autoResumeCount: 0,
  };

  return item;
}

export function triggerBrowserFileDownload(item: DownloadItem): void {
  // Create a clean dummy blob with proper mime type to trigger browser native download
  const mimeType = item.category === 'audio' 
    ? 'audio/mpeg' 
    : item.format === 'zip' 
      ? 'application/zip' 
      : 'video/mp4';

  const mockPayload = `DEATHLESS_VERIFIED_MEDIA_PAYLOAD\nTitle: ${item.title}\nFile: ${item.fileName}\nPath: ${item.downloadPath}\nQuality: ${item.quality.label}\nPlatform: ${item.platform}\nCDN: ${item.cdnInfo.cdnProvider}\nOriginal-Url: ${item.originalUrl}\nTimestamp: ${new Date().toISOString()}\n`;
  const blob = new Blob([mockPayload], { type: mimeType });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = item.fileName || `${item.title.substring(0, 30)}.${item.format}`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

function getDefaultInitialHistory(): DownloadItem[] {
  return [
    {
      id: 'dl_hist_1',
      title: 'YouTube 4K Nature Documentary - Costa Rica Rainforests in 60FPS HDR',
      fileName: 'Costa_Rica_Rainforests_60FPS_HDR_4K.mp4',
      downloadPath: '~/Downloads/Deathless/Costa_Rica_Rainforests_60FPS_HDR_4K.mp4',
      originalUrl: 'https://youtube.com/watch?v=LXb3EKWsInQ',
      platform: 'youtube',
      category: 'video',
      format: 'mp4',
      quality: {
        id: 'q-4k',
        label: '4K Ultra HD (2160p @ 60fps)',
        resolution: '3840 x 2160',
        qualityTag: '4K',
        format: 'mp4',
        isAudioOnly: false,
        bitrateKbps: 24000,
        fps: 60,
        codec: 'AV1 / HEVC Main 10',
        approxSizeMb: 1420,
      },
      totalBytes: 1420 * 1024 * 1024,
      downloadedBytes: 1420 * 1024 * 1024,
      status: 'completed',
      speedBytesPerSec: 0,
      etaSeconds: 0,
      chunks: [],
      thumbnail: 'https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=800&auto=format&fit=crop&q=60',
      duration: '18:45',
      createdAt: Date.now() - 3600 * 1000 * 2,
      completedAt: Date.now() - 3600 * 1000 * 2 + 65000,
      cdnInfo: {
        cdnProvider: 'Google Video Backbone (Googlevideo CDN)',
        nodeLocation: 'Frankfurt Central Edge IX (FRA-02), DE',
        edgeServerIp: '172.217.18.206',
        protocol: 'HTTP/3 (QUIC-RFC9000)',
        latencyMs: 14,
        supportsRangeResume: true,
        directStreamUrl: 'https://rr2---sn-4g5edn7k.googlevideo.com/videoplayback?id=cr1',
        contentLength: 1488977920,
        contentType: 'video/mp4',
      },
      isEncrypted: true,
      vaultStored: true,
      autoResumeCount: 1,
    },
    {
      id: 'dl_hist_2',
      title: 'TikTok Viral Sound Studio Remix (Original Audio 320kbps MP3)',
      fileName: 'TikTok_Viral_Sound_Studio_Remix_320k.mp3',
      downloadPath: '~/Downloads/Deathless/TikTok_Viral_Sound_Studio_Remix_320k.mp3',
      originalUrl: 'https://tiktok.com/@creator/video/719283749281',
      platform: 'tiktok',
      category: 'audio',
      format: 'mp3',
      quality: {
        id: 'q-audio-320',
        label: 'Audio Only - 320 kbps High Fidelity MP3',
        resolution: 'Studio Stereo',
        qualityTag: '320k',
        format: 'mp3',
        isAudioOnly: true,
        bitrateKbps: 320,
        codec: 'LAME MP3 v3.100 (48.0 kHz)',
        approxSizeMb: 18,
      },
      totalBytes: 18 * 1024 * 1024,
      downloadedBytes: 18 * 1024 * 1024,
      status: 'completed',
      speedBytesPerSec: 0,
      etaSeconds: 0,
      chunks: [],
      thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=60',
      duration: '03:12',
      createdAt: Date.now() - 3600 * 1000 * 5,
      completedAt: Date.now() - 3600 * 1000 * 5 + 4000,
      cdnInfo: {
        cdnProvider: 'ByteDance Akamai Edge Infrastructure',
        nodeLocation: 'Singapore Central POP (SIN-05), SG',
        edgeServerIp: '104.93.88.14',
        protocol: 'HTTP/3 (QUIC-Q050)',
        latencyMs: 19,
        supportsRangeResume: true,
        directStreamUrl: 'https://v16-webapp-prime.tiktokcdn.com/audio/320k',
        contentLength: 18874368,
        contentType: 'audio/mpeg',
      },
      isEncrypted: true,
      vaultStored: true,
      autoResumeCount: 0,
    },
    {
      id: 'dl_hist_3',
      title: 'Facebook Watch - Architectural Marvels of Istanbul (1080p 60fps)',
      fileName: 'Architectural_Marvels_of_Istanbul_1080p.mkv',
      downloadPath: '~/Downloads/Deathless/Architectural_Marvels_of_Istanbul_1080p.mkv',
      originalUrl: 'https://facebook.com/watch/?v=982347102938',
      platform: 'facebook',
      category: 'video',
      format: 'mkv',
      quality: {
        id: 'q-1080p60',
        label: '1080p Full HD (60fps High Bitrate MKV)',
        resolution: '1920 x 1080',
        qualityTag: '1080p',
        format: 'mkv',
        isAudioOnly: false,
        bitrateKbps: 6500,
        fps: 60,
        codec: 'H.264 / AVC High@L4.2',
        approxSizeMb: 520,
      },
      totalBytes: 520 * 1024 * 1024,
      downloadedBytes: 520 * 1024 * 1024,
      status: 'completed',
      speedBytesPerSec: 0,
      etaSeconds: 0,
      chunks: [],
      thumbnail: 'https://images.unsplash.com/photo-1541432901042-2d8bd64b4a9b?w=800&auto=format&fit=crop&q=60',
      duration: '09:20',
      createdAt: Date.now() - 3600 * 1000 * 12,
      completedAt: Date.now() - 3600 * 1000 * 12 + 28000,
      cdnInfo: {
        cdnProvider: 'Meta Edge Network (FNA Point of Presence)',
        nodeLocation: 'Ashburn Data Center Tier-4 (IAD-12), US',
        edgeServerIp: '157.240.22.35',
        protocol: 'HTTP/2 (Zero-RTT TLS 1.3)',
        latencyMs: 24,
        supportsRangeResume: true,
        directStreamUrl: 'https://video.fash1-1.fna.fbcdn.net/v/t39.25447-2/direct.mp4',
        contentLength: 545259520,
        contentType: 'video/mp4',
      },
      isEncrypted: true,
      vaultStored: true,
      autoResumeCount: 0,
    },
  ];
}
